#!/usr/bin/env bash
# build_ipa.sh —— 生成 TrollStore 可直接安装的 ScreenTool.ipa
set -euo pipefail
cd "$(dirname "$0")"

command -v xcodegen >/dev/null || { echo "缺少 xcodegen: brew install xcodegen"; exit 1; }
command -v xcodebuild >/dev/null || { echo "缺少 Xcode 命令行工具"; exit 1; }

echo "==> 生成工程"
xcodegen generate

echo "==> 编译 (Release / arm64 / 免签)"
xcodebuild -project ScreenTool.xcodeproj \
  -scheme ScreenTool -configuration Release -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build

APP="build/Build/Products/Release-iphoneos/ScreenTool.app"
[ -d "$APP" ] || { echo "编译失败: $APP"; exit 1; }

echo "==> 打包 ipa"
rm -rf Payload ScreenTool.ipa
mkdir -p Payload
cp -R "$APP" Payload/
find Payload -type d -name "_CodeSignature" -exec rm -rf {} + 2>/dev/null || true
find Payload -type f -name "embedded.mobileprovision" -delete 2>/dev/null || true
zip -qry ScreenTool.ipa Payload
echo ""
echo "==> 完成: $(pwd)/ScreenTool.ipa"
echo "    安装: 文件App → 分享 → TrollStore"
echo "    验证: unzip -l ScreenTool.ipa | head -20"
