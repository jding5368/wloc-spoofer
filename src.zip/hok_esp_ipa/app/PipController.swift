// PipController.swift —— 画中画显示全图透视帧
import AVFoundation
import AVKit
import UIKit

final class PipController: NSObject {
    private let displayLayer = AVSampleBufferDisplayLayer()
    private var pipController: AVPictureInPictureController?
    private(set) var isActive = false

    override init() {
        super.init()
        displayLayer.videoGravity = .resizeAspect
    }

    func setup(inline host: UIView) {
        displayLayer.frame = host.bounds
        host.layer.addSublayer(displayLayer)
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {}
    }

    func startSilentAudio() {
        // 静音保活，PiP 需要媒体会话活跃
        let sr = 44100.0, secs = 2.0, frames = Int(sr * secs), dataSize = frames * 2
        var header = [UInt8](repeating: 0, count: 44)
        func put(_ s: String, _ at: Int) { for (i, b) in s.utf8.enumerated() { header[at + i] = b } }
        put("RIFF", 0)
        var v = UInt32(36 + dataSize).littleEndian
        withUnsafeBytes(of: &v) { header.replaceSubrange(4..<8, with: $0) }
        put("WAVEfmt ", 8)
        v = 16; withUnsafeBytes(of: &v) { header.replaceSubrange(16..<20, with: $0) }
        header[20] = 1; header[22] = 1
        v = UInt32(sr).littleEndian; withUnsafeBytes(of: &v) { header.replaceSubrange(24..<28, with: $0) }
        v = UInt32(sr * 2).littleEndian; withUnsafeBytes(of: &v) { header.replaceSubrange(28..<32, with: $0) }
        header[32] = 2; header[34] = 16
        put("data", 36)
        v = UInt32(dataSize).littleEndian; withUnsafeBytes(of: &v) { header.replaceSubrange(40..<44, with: $0) }
        var data = Data(header)
        data.append(Data(count: dataSize))
        if let player = try? AVAudioPlayer(data: data, fileTypeHint: "wav") {
            player.numberOfLoops = -1
            player.volume = 0
            player.play()
        }
    }

    func start() -> Bool {
        if pipController == nil {
            let source = AVPictureInPictureController.ContentSource(
                sampleBufferDisplayLayer: displayLayer, playbackDelegate: self)
            let c = AVPictureInPictureController(contentSource: source)
            c.delegate = self
            c.canStartPictureInPictureAutomaticallyFromInline = true
            pipController = c
        }
        guard let c = pipController, c.isPictureInPicturePossible else { return false }
        c.startPictureInPicture()
        return true
    }

    func stop() { pipController?.stopPictureInPicture(); isActive = false }

    func push(bgra: Data, width: Int, height: Int) {
        guard width > 0, height > 0, bgra.count == width * height * 4 else { return }
        guard let sample = Self.makeSample(bgra: bgra, width: width, height: height) else { return }
        if displayLayer.status == .failed { displayLayer.flush() }
        displayLayer.enqueue(sample)
    }

    private static func makeSample(bgra: Data, width: Int, height: Int) -> CMSampleBuffer? {
        let attrs: [CFString: Any] = [
            kCVPixelBufferIOSurfacePropertiesKey: [:] as CFDictionary,
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA,
        ]
        var pbOut: CVPixelBuffer?
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                  attrs as CFDictionary, &pbOut) == kCVReturnSuccess,
              let pb = pbOut else { return nil }
        CVPixelBufferLockBaseAddress(pb, [])
        if let base = CVPixelBufferGetBaseAddress(pb) {
            let stride = CVPixelBufferGetBytesPerRow(pb)
            bgra.withUnsafeBytes { raw in
                guard let src = raw.baseAddress else { return }
                for y in 0..<height {
                    memcpy(base.advanced(by: y * stride), src.advanced(by: y * width * 4), width * 4)
                }
            }
        }
        CVPixelBufferUnlockBaseAddress(pb, [])
        var fmt: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault,
                                                           imageBuffer: pb,
                                                           formatDescriptionOut: &fmt) == noErr,
              let f = fmt else { return nil }
        var timing = CMSampleTimingInfo(duration: CMTime(value: 1, timescale: 30),
                                        presentationTimeStamp: CMClockGetTime(CMClockGetHostTimeClock()),
                                        decodeTimeStamp: .invalid)
        var out: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault,
                                                       imageBuffer: pb,
                                                       formatDescription: f,
                                                       sampleTiming: &timing,
                                                       sampleBufferOut: &out) == noErr else { return nil }
        return out
    }
}

extension PipController: AVPictureInPictureControllerDelegate {
    func pictureInPictureControllerDidStartPictureInPicture(_ c: AVPictureInPictureController) {
        isActive = true
    }
    func pictureInPictureControllerDidStopPictureInPicture(_ c: AVPictureInPictureController) {
        isActive = false
    }
}

extension PipController: AVPictureInPictureSampleBufferPlaybackDelegate {
    func pictureInPictureController(_ c: AVPictureInPictureController, setPlaying playing: Bool) {}
    func pictureInPictureControllerTimeRangeForPlayback(_ c: AVPictureInPictureController) -> CMTimeRange {
        CMTimeRange(start: .negativeInfinity, duration: .positiveInfinity)
    }
    func pictureInPictureControllerIsPlaybackPaused(_ c: AVPictureInPictureController) -> Bool { false }
    func pictureInPictureController(_ c: AVPictureInPictureController,
                                   didTransitionToRenderSize size: CMVideoDimensions) {}
    func pictureInPictureController(_ c: AVPictureInPictureController,
                                   skipByInterval interval: CMTime,
                                   completion handler: @escaping () -> Void) { handler() }
}
