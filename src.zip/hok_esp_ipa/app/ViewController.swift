// ViewController.swift —— 精致 UI + 跨进程扫描 + 全图透视画中画
import UIKit

// MARK: - 颜色工具

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255.0,
                  green: CGFloat((hex >> 8) & 0xFF) / 255.0,
                  blue: CGFloat(hex & 0xFF) / 255.0,
                  alpha: alpha)
    }
    static let bgTop = UIColor(hex: 0x070a14)
    static let bgMid = UIColor(hex: 0x101a34)
    static let accent = UIColor(hex: 0x4f7cff)
    static let mint = UIColor(hex: 0x2dd4bf)
    static let danger = UIColor(hex: 0xff5a6a)
    static let cardBg = UIColor(white: 1, alpha: 0.06)
}

// MARK: - 呼吸圆点

final class PulseDot: UIView {
    var dotColor: UIColor = .gray { didSet { inner.backgroundColor = dotColor } }
    private let inner = UIView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        inner.frame = bounds
        inner.layer.cornerRadius = bounds.width / 2
        inner.backgroundColor = dotColor
        addSubview(inner)
        let a = CABasicAnimation(keyPath: "opacity")
        a.fromValue = 0.35; a.toValue = 1.0; a.duration = 1.1
        a.autoreverses = true; a.repeatCount = .infinity
        layer.add(a, forKey: "pulse")
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        inner.frame = bounds
        inner.layer.cornerRadius = bounds.width / 2
    }
}

// MARK: - 渐变按钮

final class GradientButton: UIButton {
    private let gradient = CAGradientLayer()

    init(title: String) {
        super.init(frame: .zero)
        setTitle(title, for: .normal)
        setTitleColor(.white, for: .normal)
        titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        gradient.colors = [UIColor.accent.cgColor, UIColor.mint.cgColor]
        gradient.startPoint = CGPoint(x: 0, y: 0)
        gradient.endPoint = CGPoint(x: 1, y: 1)
        layer.insertSublayer(gradient, at: 0)
        layer.cornerRadius = 28
        layer.shadowColor = UIColor.accent.cgColor
        layer.shadowOpacity = 0.45
        layer.shadowRadius = 14
        layer.shadowOffset = .zero
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradient.frame = bounds
        gradient.cornerRadius = bounds.height / 2
        layer.cornerRadius = bounds.height / 2
    }

    override var isHighlighted: Bool {
        didSet {
            UIView.animate(withDuration: 0.18) {
                self.transform = self.isHighlighted ? CGAffineTransform(scaleX: 0.96, y: 0.96)
                                                    : .identity
                self.alpha = self.isHighlighted ? 0.85 : 1
            }
        }
    }
}

// MARK: - 主界面

final class ViewController: UIViewController {
    private let pip = PipController()
    private let statusPill = UIView()
    private let statusDot = PulseDot(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
    private let statusLabel = UILabel()
    private let radarHost = UIView()
    private let infoCard = UIView()
    private let connectValue = UILabel()
    private let baseValue = UILabel()
    private let enemyValue = UILabel()
    private let startBtn = GradientButton(title: "开启透视")

    private var runtime = HokRuntime()
    private var attached = false
    private var scanning = false
    private var lastEnemyCount: Int32 = 0
    private let scanQueue = DispatchQueue(label: "scan", qos: .utility)
    private var renderTimer: Timer?
    private let renderW: Int32 = 512, renderH: Int32 = 512

    private var cfg: HokConfig = {
        var c = HokConfig()
        c.il2cppBase = 0
        c.metadataRegistrationOff = 0x0          // TODO dump_runtime.py 生成
        c.classStaticFieldsOff = 0x0             // TODO
        c.actorRootTypeIndex = -1                // TODO
        c.actorManagerTypeIndex = -1             // TODO
        c.actorManagerInstanceFieldOff = 0x0     // TODO
        c.actorListFieldOff = 0x0                // TODO
        c.offLocation = 0x0                      // TODO
        c.offForward = 0x0
        c.offHp = 0x0                            // TODO
        c.offEp = 0x0
        c.offCamp = 0x0                          // TODO
        c.offConfigId = 0x0
        c.offDead = 0x0
        c.offVisible = 0x0
        c.offIsHero = 0x0
        c.mapHalf = 60.0
        c.vIntScale = 100.0
        return c
    }()

    // MARK: - 生命周期

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        buildUI()
        pip.setup(inline: radarHost)
        startRenderLoop()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pip.displayLayer.frame = radarHost.bounds
    }

    // MARK: - 背景

    private func setupBackground() {
        let bg = CAGradientLayer()
        bg.frame = view.bounds
        bg.colors = [UIColor.bgTop.cgColor, UIColor.bgMid.cgColor, UIColor.bgTop.cgColor]
        bg.locations = [0, 0.5, 1]
        bg.startPoint = CGPoint(x: 0, y: 0)
        bg.endPoint = CGPoint(x: 1, y: 1)
        view.layer.insertSublayer(bg, at: 0)

        let glow = UIView(frame: CGRect(x: -120, y: -120, width: 300, height: 300))
        glow.backgroundColor = UIColor.accent.withAlphaComponent(0.14)
        glow.layer.cornerRadius = 150
        view.addSubview(glow)

        let g2 = UIView(frame: CGRect(x: view.bounds.width - 170, y: view.bounds.height - 330,
                                      width: 280, height: 280))
        g2.backgroundColor = UIColor.mint.withAlphaComponent(0.1)
        g2.layer.cornerRadius = 140
        view.addSubview(g2)
    }

    // MARK: - UI

    private func buildUI() {
        let title = UILabel()
        title.text = "屏幕工具"
        title.textColor = .white
        title.font = .systemFont(ofSize: 30, weight: .bold)

        let subtitle = UILabel()
        subtitle.text = "雷达增强 · 静默运行"
        subtitle.textColor = UIColor(white: 0.55, alpha: 1)
        subtitle.font = .systemFont(ofSize: 14, weight: .regular)

        statusPill.backgroundColor = UIColor.cardBg
        statusPill.layer.cornerRadius = 15
        statusPill.translatesAutoresizingMaskIntoConstraints = false
        statusDot.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = "未连接"
        statusLabel.textColor = UIColor(white: 0.85, alpha: 1)
        statusLabel.font = .systemFont(ofSize: 13, weight: .medium)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusPill.addSubview(statusDot)
        statusPill.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            statusPill.heightAnchor.constraint(equalToConstant: 30),
            statusDot.leadingAnchor.constraint(equalTo: statusPill.leadingAnchor, constant: 12),
            statusDot.centerYAnchor.constraint(equalTo: statusPill.centerYAnchor),
            statusDot.widthAnchor.constraint(equalToConstant: 10),
            statusDot.heightAnchor.constraint(equalToConstant: 10),
            statusLabel.leadingAnchor.constraint(equalTo: statusDot.trailingAnchor, constant: 8),
            statusLabel.trailingAnchor.constraint(equalTo: statusPill.trailingAnchor, constant: -14),
            statusLabel.centerYAnchor.constraint(equalTo: statusPill.centerYAnchor),
        ])

        let header = UIStackView(arrangedSubviews: [title, subtitle])
        header.axis = .vertical
        header.spacing = 4

        let topRow = UIStackView(arrangedSubviews: [header, statusPill])
        topRow.axis = .horizontal
        topRow.alignment = .center
        topRow.distribution = .equalSpacing
        topRow.translatesAutoresizingMaskIntoConstraints = false

        radarHost.backgroundColor = UIColor(white: 0, alpha: 0.5)
        radarHost.layer.cornerRadius = 24
        radarHost.layer.masksToBounds = true
        radarHost.layer.borderWidth = 1
        radarHost.layer.borderColor = UIColor.accent.withAlphaComponent(0.5).cgColor
        radarHost.layer.shadowColor = UIColor.accent.cgColor
        radarHost.layer.shadowOpacity = 0.4
        radarHost.layer.shadowRadius = 18
        radarHost.layer.shadowOffset = .zero
        radarHost.translatesAutoresizingMaskIntoConstraints = false

        infoCard.backgroundColor = UIColor.cardBg
        infoCard.layer.cornerRadius = 20
        infoCard.translatesAutoresizingMaskIntoConstraints = false

        let infoStack = UIStackView(arrangedSubviews: [
            makeInfoCell(title: "连接", value: connectValue),
            makeInfoCell(title: "敌人数", value: enemyValue),
            makeInfoCell(title: "基址", value: baseValue),
        ])
        infoStack.axis = .horizontal
        infoStack.distribution = .fillEqually
        infoStack.translatesAutoresizingMaskIntoConstraints = false
        infoCard.addSubview(infoStack)
        NSLayoutConstraint.activate([
            infoStack.leadingAnchor.constraint(equalTo: infoCard.leadingAnchor, constant: 8),
            infoStack.trailingAnchor.constraint(equalTo: infoCard.trailingAnchor, constant: -8),
            infoStack.topAnchor.constraint(equalTo: infoCard.topAnchor, constant: 14),
            infoStack.bottomAnchor.constraint(equalTo: infoCard.bottomAnchor, constant: -14),
        ])

        let hint = UILabel()
        hint.text = "仅限授权测试环境使用"
        hint.textColor = UIColor(white: 0.4, alpha: 1)
        hint.font = .systemFont(ofSize: 12)
        hint.textAlignment = .center

        startBtn.addTarget(self, action: #selector(tapStart), for: .touchUpInside)

        let root = UIStackView(arrangedSubviews: [topRow, radarHost, infoCard, startBtn, hint])
        root.axis = .vertical
        root.spacing = 22
        root.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(root)

        NSLayoutConstraint.activate([
            root.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 22),
            root.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -22),
            root.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            radarHost.heightAnchor.constraint(equalTo: radarHost.widthAnchor),
            startBtn.heightAnchor.constraint(equalToConstant: 56),
            infoCard.heightAnchor.constraint(equalToConstant: 76),
        ])
    }

    private func makeInfoCell(title: String, value: UILabel) -> UIStackView {
        let t = UILabel()
        t.text = title
        t.textColor = UIColor(white: 0.5, alpha: 1)
        t.font = .systemFont(ofSize: 12, weight: .medium)
        value.textColor = .white
        value.font = .monospacedSystemFont(ofSize: 15, weight: .semibold)
        value.numberOfLines = 1
        value.adjustsFontSizeToFitWidth = true
        let stack = UIStackView(arrangedSubviews: [t, value])
        stack.axis = .vertical
        stack.spacing = 4
        stack.alignment = .center
        return stack
    }

    // MARK: - 状态

    private func setStatus(_ text: String, color: UIColor) {
        statusLabel.text = text
        statusDot.dotColor = color
    }

    // MARK: - 启动

    @objc private func tapStart() {
        if !attached { attachAndResolve() }
        pip.startSilentAudio()
        _ = pip.start()
        setStatus(attached ? "透视运行中" : "连接中…", color: attached ? .mint : .systemYellow)
    }

    private func attachAndResolve() {
        scanQueue.async { [weak self] in
            guard let self else { return }
            var err = [CChar](repeating: 0, count: 256)
            var rt = HokRuntime()
            let ok = hok_attach("sgame", &rt, &err, 256) && hok_resolve(&self.cfg, &rt, &err, 256)
            DispatchQueue.main.async {
                if ok {
                    self.runtime = rt
                    self.attached = true
                    self.connectValue.text = "已连接"
                    self.baseValue.text = String(format: "0x%llX", rt.il2cppBase)
                    self.setStatus("透视运行中", color: .mint)
                    self.startScanning()
                } else {
                    self.connectValue.text = "失败"
                    let msg = err.withUnsafeBufferPointer { String(cString: $0.baseAddress!) }
                    self.setStatus(msg, color: .danger)
                }
            }
        }
    }

    // MARK: - 反检测扫描：随机间隔 + 前台判定 + 低频

    private func startScanning() {
        guard !scanning else { return }
        scanning = true
        scanQueue.async { [weak self] in self?.scanLoop() }
    }

    private func scanLoop() {
        var enemies = [HokEnemy](repeating: HokEnemy(), count: 256)
        while scanning {
            let active = UIApplication.shared.applicationState == .active || pip.isActive
            if active && attached {
                let n = enemies.withUnsafeMutableBufferPointer { buf in
                    hok_scan(&cfg, &runtime, buf.baseAddress, Int32(buf.count))
                }
                if n > 0 {
                    lastEnemyCount = n
                    let w = renderW, h = renderH
                    var frame = [UInt8](repeating: 0, count: Int(w) * Int(h) * 4)
                    frame.withUnsafeMutableBytes { raw in
                        hok_render_frame(enemies, n, w, h,
                                         raw.baseAddress?.assumingMemoryBound(to: UInt8.self))
                    }
                    DispatchQueue.main.async { [weak self] in
                        guard let self else { return }
                        self.enemyValue.text = "\(n)"
                        self.pip.push(bgra: Data(frame), width: Int(w), height: Int(h))
                    }
                }
            }
            // 随机 1.5~3.5 秒，行为像普通 app，不像高频外挂
            Thread.sleep(forTimeInterval: Double.random(in: 1.5...3.5))
        }
    }

    private func startRenderLoop() {
        renderTimer = Timer(timeInterval: 1.0 / 15.0, repeats: true) { [weak self] _ in
            guard let self, self.pip.isActive, !self.attached else { return }
            let w = Int(self.renderW), h = Int(self.renderH)
            var frame = [UInt8](repeating: 0, count: w * h * 4)
            self.pip.push(bgra: Data(frame), width: w, height: h)
        }
        RunLoop.main.add(renderTimer!, forMode: .common)
    }
}
