#!/usr/bin/env python3
# dump_runtime.py —— 汇总 Il2CppDumper 输出，生成 Swift 配置片段
# 用法:
#   python3 dump_runtime.py --dumpcs dump.cs --script script.json [--frida frida_out.txt]
# 输出: 一段可直接粘贴进 ViewController.swift 的 cfg 赋值代码
import argparse
import json
import re
import sys

def parse_type_def_index(body, class_name):
    m = re.search(r'class\s+' + class_name + r'\b[^\n]*TypeDefIndex:\s*(\d+)', body)
    if not m:
        m = re.search(r'TypeDefIndex:\s*(\d+)[^\n]*\n[^\n]*class\s+' + class_name + r'\b', body)
    return int(m.group(1)) if m else None

def parse_field_offsets(body, class_name):
    # 抓类体
    m = re.search(r'class\s+' + class_name + r'\b[^{]*\{(.*?)\n\}\s*//', body, re.S)
    if not m:
        m = re.search(r'class\s+' + class_name + r'\b[^{]*\{(.*?)\n\}', body, re.S)
    if not m:
        return {}
    out = {}
    for line in m.group(1).splitlines():
        mm = re.search(r'(\w+(?:<[^>]*>)?)\s+(\w+)\s*;\s*//\s*(0x[0-9a-fA-F]+|\d+)', line)
        if mm:
            out[mm.group(2)] = int(mm.group(3), 0)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dumpcs', required=True)
    ap.add_argument('--script', default=None)
    ap.add_argument('--frida', default=None)
    args = ap.parse_args()

    cs = open(args.dumpcs, encoding='utf-8', errors='ignore').read()
    root = parse_type_def_index(cs, 'ActorRoot')
    mgr = parse_type_def_index(cs, 'ActorManager')
    root_fields = parse_field_offsets(cs, 'ActorRoot')
    mgr_fields = parse_field_offsets(cs, 'ActorManager')

    script = {}
    if args.script:
        try:
            script = json.load(open(args.script))
        except Exception:
            pass

    # 从 script.json 找 MetadataRegistration 相对地址（常见字段名）
    meta_reg_off = None
    for key in ('MetadataRegistration', 'metadataRegistration'):
        block = script.get(key)
        if isinstance(block, dict):
            for k in ('Address', 'address'):
                if block.get(k):
                    meta_reg_off = int(block[k], 0) if isinstance(block[k], str) else int(block[k])
                    break

    # 找 Il2CppClass.static_fields 偏移（Il2CppDumper 的 il2cpp.h 里有，这里尝试从 script）
    class_static_off = None
    sm = script.get('ScriptMetadata', {}) or script.get('scriptMetadata', {})
    for k in ('StaticFieldsOffset', 'staticFieldsOffset'):
        if sm.get(k):
            class_static_off = int(sm[k], 0) if isinstance(sm[k], str) else int(sm[k])

    # 静态字段偏移：从 frida 输出解析 "Instance @ 0x" 之类
    inst_off = None
    list_off = None
    if args.frida:
        fd = open(args.frida, encoding='utf-8', errors='ignore').read()
        mm = re.search(r'Instance\s+@\s*(0x[0-9a-fA-F]+|\d+)', fd)
        if mm: inst_off = int(mm.group(1), 0)
        mm = re.search(r'(?:m_actorList|actorList|m_actors|actors)\s+@\s*(0x[0-9a-fA-F]+|\d+)', fd)
        if mm: list_off = int(mm.group(1), 0)

    def fmt(v):
        return f"0x{v:X}" if v is not None else "0x0  /* TODO */"

    print("// ===== 粘贴到 ViewController.swift 的 cfg 初始化处 =====\n")
    print(f"c.metadataRegistrationOff = {fmt(meta_reg_off)}")
    print(f"c.classStaticFieldsOff = {fmt(class_static_off)}")
    print(f"c.actorRootTypeIndex = {root if root is not None else -1}")
    print(f"c.actorManagerTypeIndex = {mgr if mgr is not None else -1}")
    print(f"c.actorManagerInstanceFieldOff = {fmt(inst_off)}")
    print(f"c.actorListFieldOff = {fmt(list_off or mgr_fields.get('m_actorList') or mgr_fields.get('actorList'))}")
    print(f"c.offLocation = {fmt(root_fields.get('location'))}")
    print(f"c.offForward = {fmt(root_fields.get('forward'))}")
    print(f"c.offHp = {fmt(root_fields.get('hp'))}")
    print(f"c.offEp = {fmt(root_fields.get('ep'))}")
    print(f"c.offCamp = {fmt(root_fields.get('camp'))}")
    print(f"c.offConfigId = {fmt(root_fields.get('configID') or root_fields.get('configId'))}")
    print(f"c.offDead = {fmt(root_fields.get('bDead'))}")
    print(f"c.offVisible = {fmt(root_fields.get('bVisible'))}")
    print(f"c.offIsHero = {fmt(root_fields.get('isHostPlayer'))}")
    print(f"c.mapHalf = 60.0")
    print(f"c.vIntScale = 100.0")
    print("\n// ===== 结束 =====")
    if not (root_fields.get('location') and root_fields.get('camp')):
        print("\n[!] 警告：ActorRoot 的 location/camp 未解析到，确认 dump.cs 是否完整。")

if __name__ == '__main__':
    main()
