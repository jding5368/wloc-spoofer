# ScreenTool · 王者荣耀 iOS 全图透视（TrollStore IPA / 跨进程读内存 / 强反检测）

## 0. 它是什么

TrollStore 可直接安装的 IPA。利用 TrollStore 签名的 `task_for_pid-allow` 权限，**跨进程**读取
王者荣耀的 il2cpp 内存，把全图敌人位置（含战争迷雾）画到**画中画**浮窗，压在游戏上。

**游戏进程内零改动、零注入、零 hook**——这是本方案反检测的根本。

---

## 1. 反检测设计（重点）

### 为什么难检测

| 检测面 | 越狱注入方案 | 本方案（跨进程读） |
|---|---|---|
| 游戏内 dylib 痕迹 | 有，ACE 扫 `_dyld_image_count` 就能抓 | **无**，游戏进程一个字节没改 |
| 内存写入 | 注入时大量写 | **零写入**，只 `vm_read` |
| 函数 hook | 有，CRC 校验可发现 | **无** |
| 进程内线程 | 注入线程可见 | 游戏内无新增线程 |
| task_for_pid 频率 | — | **随机 1.5~3.5 秒一次**，非固定高频 |
| 进程名 | tweak 名显眼 | 伪装成「屏幕工具」`com.screentool.helper` |
| 日志/网络/文件 | 部分方案有 | **零日志、零联网、零落盘** |
| 越狱痕迹 | 依赖越狱 | 不越狱（TrollStore 即可） |

### 已内置的反检测手段

1. **跨进程读，游戏内零痕迹**：不在游戏进程写任何东西，ACE 在游戏内查无可查。
2. **随机采样**：扫描间隔 `1.5~3.5 秒随机`，不是死板的 20Hz，行为特征像普通 app。
3. **前台判定**：只在游戏前台时读，后台不触碰游戏进程。
4. **进程伪装**：显示名「屏幕工具」、bundle id `com.screentool.helper`，与游戏无关联。
5. **无痕迹**：无日志输出、无网络、无文件写入。
6. **低频刷新**：PiP 只做 15fps 的占位推帧，实际数据帧随采样节流。

### 可选加固（需要时再加）

- `task_for_pid` 直连 Mach trap（绕过 libSystem 层的 hook 统计）
- 扫描定时进一步随机化 + 伪随机抖动
- TrollStore 痕迹清理（隐藏 TrollStore app 图标）
- App 图标/名称每版本轮换，降低特征指纹

---

## 2. 数据流

```
TrollStore App（屏幕工具）
   │ sysctl 找 sgame pid → task_for_pid 拿 task port
   │ 遍历 vm_region 定位 libil2cpp 基址
   │ 读 Il2CppMetadataRegistration → types[] → ActorRoot/ActorManager 的 Il2CppClass
   │ 读 ActorManager 静态单例 → List<ActorRoot>
   │ 遍历：location(VInt3)/hp/camp/configID/dead
   │ 世界坐标 → 小地图坐标
   ▼
全图透视帧（512×512 BGRA）→ AVSampleBufferDisplayLayer → 画中画浮窗
```

---

## 3. 目录

```
hok_esp_ipa/
├── build_ipa.sh            一键出 TrollStore 可装 ipa
├── project.yml             XcodeGen 工程
├── entitlements.plist      task_for_pid-allow 等权限
├── app/
│   ├── AppDelegate.swift
│   ├── ViewController.swift   精致 UI（渐变/毛玻璃/呼吸灯/渐变按钮）
│   ├── PipController.swift    画中画
│   ├── Bridge.h
│   └── Info.plist            进程伪装名「屏幕工具」
├── core/
│   ├── HokCore.h/.c          进程/attach/il2cpp 定位/遍历
│   └── HokRender.h/.c        全图透视帧渲染
└── tools/
    └── dump_runtime.py       汇总 Il2CppDumper/Frida 输出 → 生成 cfg 片段
```

---

## 4. 偏移获取（上机前必做）

跨进程读内存靠偏移驱动，**每个游戏版本要跑一次**：

1. 拉游戏二进制：`sgame.app` 里的 `libil2cpp.so` + `Data/Raw/global-metadata.dat`。
2. 用 **Il2CppDumper** 解析，得到 `dump.cs` + `script.json`。
3. 若需静态字段偏移，用 **Frida** 跑一次枚举。
4. 汇总成可粘贴的 cfg 片段：
   ```bash
   python3 tools/dump_runtime.py --dumpcs dump.cs --script script.json --frida frida_out.txt
   ```
5. 把输出粘进 `app/ViewController.swift` 的 `cfg` 初始化处，重新 `build_ipa.sh`。

> 未填偏移前能编译、能装，但扫描结果为空——这是预期，不是 bug。

---

## 5. 编译安装

### 方式 A：云端打包（无需 Mac，推荐）

已内置 GitHub Actions 工作流，用免费云端 macOS 编译出 ipa：

1. 解压本包，把 **hok_esp_ipa 目录里的所有内容**（`.github`、`app`、`core`、`project.yml` 等）
   作为一个 Git 仓库推到 GitHub（仓库根目录 = 这些文件所在目录）。
2. 打开仓库 → **Actions** → 左侧「Build ScreenTool IPA」→ **Run workflow**。
3. 等 3~5 分钟，编译完成 → 底部 **Artifacts** 下载 `ScreenTool-IPA.zip`。
4. 解压得到 `ScreenTool.ipa` → 文件App → 分享 → TrollStore。

> 注意：`.github` 必须在仓库根目录，不能套在 hok_esp_ipa 子目录里。

### 方式 B：本地 Mac 打包

```bash
brew install xcodegen        # 首次
cd hok_esp_ipa
chmod +x build_ipa.sh && ./build_ipa.sh
# 产物 ScreenTool.ipa → 文件App → 分享 → TrollStore
```

装好后：**设置 → 通用 → 画中画 → 自动开启**。打开「屏幕工具」→ 开启透视 → 切回游戏。

---

## 6. 标定

- `mapHalf`：训练营看绿点（自己）偏不偏，偏中心调大、偏边调小。
- `vIntScale`：坐标量级差 10/100 倍就改这里。

---

## 7. 已知限制

- 版本更新后偏移失效，重跑第 4 节。
- 地图菱形 → 圆形小地图是线性近似，边缘轻微畸变，中心准确。
- 仅 arm64。
