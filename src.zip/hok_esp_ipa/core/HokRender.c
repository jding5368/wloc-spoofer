// HokRender.c —— 软件光栅：全图透视帧（圆/环/点），无平台依赖
#include "HokRender.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

static void set_px(unsigned char* buf, int w, int h, int x, int y, unsigned char r,
                   unsigned char g, unsigned char b, unsigned char a) {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    unsigned char* p = buf + ((size_t)y * w + x) * 4;
    if (a >= 250) {
        p[0] = b;
        p[1] = g;
        p[2] = r;
        p[3] = 255;
        return;
    }
    p[0] = (unsigned char)((b * a + p[0] * (255 - a)) / 255);
    p[1] = (unsigned char)((g * a + p[1] * (255 - a)) / 255);
    p[2] = (unsigned char)((r * a + p[2] * (255 - a)) / 255);
    p[3] = 255;
}

static void disc(unsigned char* buf, int w, int h, int cx, int cy, int rad, unsigned char r,
                 unsigned char g, unsigned char b, unsigned char a) {
    const int r2 = rad * rad;
    for (int y = -rad; y <= rad; ++y)
        for (int x = -rad; x <= rad; ++x)
            if (x * x + y * y <= r2) set_px(buf, w, h, cx + x, cy + y, r, g, b, a);
}

static void ring(unsigned char* buf, int w, int h, int cx, int cy, int rad, unsigned char r,
                 unsigned char g, unsigned char b) {
    const int ro = rad * rad;
    const int ri = (rad - 1) * (rad - 1);
    for (int y = -rad; y <= rad; ++y)
        for (int x = -rad; x <= rad; ++x) {
            const int d = x * x + y * y;
            if (d <= ro && d >= ri) set_px(buf, w, h, cx + x, cy + y, r, g, b, 255);
        }
}

static void line(unsigned char* buf, int w, int h, int x0, int y0, int x1, int y1, unsigned char r,
                 unsigned char g, unsigned char b) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        set_px(buf, w, h, x0, y0, r, g, b, 255);
        if (x0 == x1 && y0 == y1) break;
        const int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

void hok_render_solid(int w, int h, unsigned char r, unsigned char g, unsigned char b,
                      unsigned char* out) {
    for (int i = 0; i < w * h; ++i) {
        out[i * 4 + 0] = b;
        out[i * 4 + 1] = g;
        out[i * 4 + 2] = r;
        out[i * 4 + 3] = 255;
    }
}

void hok_render_frame(const HokEnemy* enemies, int count, int w, int h, unsigned char* out) {
    // 背景
    for (int i = 0; i < w * h; ++i) {
        out[i * 4 + 0] = 16;
        out[i * 4 + 1] = 20;
        out[i * 4 + 2] = 28;
        out[i * 4 + 3] = 255;
    }
    if (w <= 0 || h <= 0) return;

    const int cx = w / 2, cy = h / 2;
    const int R = (w < h ? w : h) / 2 - 4;

    // 地图盘
    ring(out, w, h, cx, cy, R, 44, 52, 64);
    ring(out, w, h, cx, cy, R * 2 / 3, 34, 42, 52);
    ring(out, w, h, cx, cy, R / 3, 34, 42, 52);
    line(out, w, h, cx, cy - R, cx, cy + R, 30, 38, 48);
    line(out, w, h, cx - R, cy, cx + R, cy, 30, 38, 48);

    int enemyCount = 0;
    for (int i = 0; i < count; ++i) {
        const HokEnemy* e = &enemies[i];
        if (!e->valid) continue;
        float nx, ny;
        hok_world_to_minimap(e->x, e->z, 60.0f, &nx, &ny);
        const int px = cx + (int)lroundf((nx - 0.5f) * 2.0f * R);
        const int py = cy + (int)lroundf((ny - 0.5f) * 2.0f * R);

        unsigned char r, g, b;
        if (e->camp == 1) { r = 255; g = 60; b = 60; }
        else if (e->camp == 0) { r = 60; g = 220; b = 110; }
        else { r = 70; g = 150; b = 255; }

        if (e->camp == 1) {
            disc(out, w, h, px, py, 7, 255, 40, 40, 90);   // 光晕
            disc(out, w, h, px, py, 4, r, g, b, 255);
            enemyCount++;
        } else {
            disc(out, w, h, px, py, 3, r, g, b, 255);
        }
    }
}
