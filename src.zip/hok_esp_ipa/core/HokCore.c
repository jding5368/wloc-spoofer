// HokCore.c —— TrollStore 跨进程读内存：attach → 定位 il2cpp → 遍历 Actor
#include "HokCore.h"

#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <mach-o/loader.h>
#include <sys/sysctl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// ---- 读内存 ----
static bool vm_read(task_t task, uint64_t addr, void* buf, size_t len) {
    if (!task || !buf || !len) return false;
    mach_vm_size_t out = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, (mach_vm_address_t)addr, len,
                                              (mach_vm_address_t)buf, &out);
    return kr == KERN_SUCCESS && out == len;
}

static bool vm_read_u64(task_t task, uint64_t addr, uint64_t* out) {
    return vm_read(task, addr, out, sizeof(*out));
}

static bool vm_read_u32(task_t task, uint64_t addr, uint32_t* out) {
    return vm_read(task, addr, out, sizeof(*out));
}

// ---- 进程查找 ----
static int find_pid(const char* name) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    size_t len = 0;
    if (sysctl(mib, 4, NULL, &len, NULL, 0) != 0) return -1;
    struct kinfo_proc* procs = (struct kinfo_proc*)malloc(len);
    if (!procs) return -1;
    if (sysctl(mib, 4, procs, &len, NULL, 0) != 0) {
        free(procs);
        return -1;
    }
    const int n = (int)(len / sizeof(struct kinfo_proc));
    int pid = -1;
    for (int i = 0; i < n; ++i) {
        if (strcmp(procs[i].kp_proc.p_comm, name) == 0) {
            pid = (int)procs[i].kp_proc.p_pid;
            break;
        }
    }
    free(procs);
    return pid;
}

bool hok_attach(const char* procName, HokRuntime* rt, char* err, size_t errLen) {
    if (!procName || !rt) return false;
    memset(rt, 0, sizeof(*rt));
    const int pid = find_pid(procName);
    if (pid < 0) {
        snprintf(err, errLen, "进程未找到: %s（请确认游戏正在运行）", procName);
        return false;
    }
    task_t task = 0;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) {
        snprintf(err, errLen, "task_for_pid 失败 (kr=%d)，确认已用 TrollStore 安装", kr);
        return false;
    }
    rt->task = task;
    return true;
}

// ---- 定位 libil2cpp 基址（遍历内存区域，识别 Mach-O 的 dylib name） ----
static bool macho_dylib_is_il2cpp(task_t task, uint64_t hdrAddr) {
    struct mach_header_64 mh;
    if (!vm_read(task, hdrAddr, &mh, sizeof(mh))) return false;
    if (mh.magic != MH_MAGIC_64) return false;

    uint64_t lc = hdrAddr + sizeof(struct mach_header_64);
    for (uint32_t i = 0; i < mh.ncmds; ++i) {
        struct load_command cmd;
        if (!vm_read(task, lc, &cmd, sizeof(cmd))) return false;
        if (cmd.cmd == LC_ID_DYLIB) {
            struct dylib_command dc;
            if (!vm_read(task, lc, &dc, sizeof(dc))) return false;
            char name[128] = {0};
            if (dc.dylib.name.offset < sizeof(dc)) {
                uint64_t nameAddr = lc + dc.dylib.name.offset;
                if (vm_read(task, nameAddr, name, sizeof(name) - 1)) {
                    return strstr(name, "il2cpp") != NULL;
                }
            }
            return false;
        }
        lc += cmd.cmdsize;
        if (cmd.cmdsize == 0) break;
    }
    return false;
}

static uint64_t find_il2cpp_base(task_t task) {
    mach_vm_address_t addr = 0;
    mach_vm_size_t size = 0;
    natural_t depth = 0;
    vm_region_submap_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;

    for (;;) {
        count = VM_REGION_SUBMAP_INFO_COUNT_64;
        kern_return_t kr = mach_vm_region_recurse(task, &addr, &size, &depth,
                                                  (vm_region_recurse_info_t)&info, &count);
        if (kr != KERN_SUCCESS) break;
        if (size >= sizeof(struct mach_header_64) && macho_dylib_is_il2cpp(task, addr)) {
            return addr;
        }
        addr += size;
        if (addr == 0) break;
    }
    return 0;
}

// ---- il2cpp 运行时定位 ----
// types 数组元素 = Il2CppType*，其 data.classHandle 在偏移 0（v24–v29 通用）
bool hok_resolve(const HokConfig* cfg, HokRuntime* rt, char* err, size_t errLen) {
    if (!cfg || !rt || !rt->task) return false;

    uint64_t base = cfg->il2cppBase;
    if (base == 0) {
        base = find_il2cpp_base(rt->task);
        if (base == 0) {
            snprintf(err, errLen, "未找到 libil2cpp（游戏可能未加载完成）");
            return false;
        }
    }
    rt->il2cppBase = base;
    rt->metadataReg = base + cfg->metadataRegistrationOff;

    // Il2CppMetadataRegistration：typesCount + types 指针（前两字段）
    uint32_t typesCount = 0;
    uint64_t typesArray = 0;
    if (!vm_read_u32(rt->task, rt->metadataReg, &typesCount) ||
        !vm_read_u64(rt->task, rt->metadataReg + 8, &typesArray)) {
        snprintf(err, errLen, "读取 MetadataRegistration 失败");
        return false;
    }
    rt->typesCount = typesCount;
    rt->typesArray = typesArray;

    if (cfg->actorRootTypeIndex >= 0 && (uint32_t)cfg->actorRootTypeIndex < typesCount) {
        uint64_t typePtr = 0;
        if (!vm_read_u64(rt->task, typesArray + (uint64_t)cfg->actorRootTypeIndex * 8, &typePtr)) {
            snprintf(err, errLen, "读取 ActorRoot type 失败");
            return false;
        }
        // Il2CppType.data.classHandle @ 0
        vm_read_u64(rt->task, typePtr, &rt->actorRootClass);
    }
    if (cfg->actorManagerTypeIndex >= 0 && (uint32_t)cfg->actorManagerTypeIndex < typesCount) {
        uint64_t typePtr = 0;
        if (!vm_read_u64(rt->task, typesArray + (uint64_t)cfg->actorManagerTypeIndex * 8, &typePtr)) {
            snprintf(err, errLen, "读取 ActorManager type 失败");
            return false;
        }
        vm_read_u64(rt->task, typePtr, &rt->actorManagerClass);
    }

    if (!rt->actorRootClass || !rt->actorManagerClass) {
        snprintf(err, errLen, "类解析失败 root=%llx mgr=%llx", rt->actorRootClass, rt->actorManagerClass);
        return false;
    }
    return true;
}

// ---- 读 ActorManager 静态单例 ----
static uint64_t read_mgr_instance(const HokConfig* cfg, HokRuntime* rt) {
    uint64_t staticFields = 0;
    if (!vm_read_u64(rt->task, rt->actorManagerClass + cfg->classStaticFieldsOff, &staticFields)) {
        return 0;
    }
    uint64_t inst = 0;
    if (!vm_read_u64(rt->task, staticFields + cfg->actorManagerInstanceFieldOff, &inst)) {
        return 0;
    }
    return inst;
}

// ---- 遍历 List<ActorRoot> ----
int hok_scan(const HokConfig* cfg, HokRuntime* rt, HokEnemy* out, int maxOut) {
    if (!cfg || !rt || !out || maxOut <= 0) return 0;
    memset(out, 0, sizeof(HokEnemy) * (size_t)maxOut);

    const uint64_t mgr = read_mgr_instance(cfg, rt);
    if (!mgr) return 0;

    // List<T>：items@0x10, size@0x18（64 位）
    uint64_t items = 0;
    int32_t size = 0;
    if (!vm_read_u64(rt->task, mgr + cfg->actorListFieldOff, &items) ||
        !vm_read_u32(rt->task, mgr + cfg->actorListFieldOff + 0x18, (uint32_t*)&size)) {
        return 0;
    }
    if (!items || size <= 0 || size > 4096) return 0;

    // 数组数据起点 0x20
    const uint64_t dataBase = items + 0x20;
    int n = 0;
    for (int i = 0; i < size && n < maxOut; ++i) {
        uint64_t actor = 0;
        if (!vm_read_u64(rt->task, dataBase + (uint64_t)i * 8, &actor)) continue;
        if (!actor) continue;

        HokEnemy e;
        memset(&e, 0, sizeof(e));
        e.camp = -1;

        int32_t loc[3] = {0, 0, 0};
        if (cfg->offLocation) {
            uint64_t p = actor + cfg->offLocation;
            for (int k = 0; k < 3; ++k) {
                int32_t v = 0;
                vm_read(rt->task, p + (uint64_t)k * 4, &v, 4);
                loc[k] = v;
            }
        }
        const float s = cfg->vIntScale > 0 ? cfg->vIntScale : 100.0f;
        e.x = loc[0] / s;
        e.y = loc[1] / s;
        e.z = loc[2] / s;

        if (cfg->offHp) {
            int32_t v = 0;
            vm_read(rt->task, actor + cfg->offHp, &v, 4);
            e.hp = v;
        }
        if (cfg->offCamp) {
            int32_t v = 0;
            vm_read(rt->task, actor + cfg->offCamp, &v, 4);
            e.camp = v;
        }
        if (cfg->offDead) {
            uint8_t v = 0;
            vm_read(rt->task, actor + cfg->offDead, &v, 1);
            e.dead = v != 0;
        }
        if (cfg->offVisible) {
            uint8_t v = 0;
            vm_read(rt->task, actor + cfg->offVisible, &v, 1);
            e.valid = true;  // 字段在则结构有效
        }
        e.valid = true;
        out[n++] = e;
    }
    return n;
}

void hok_world_to_minimap(float wx, float wz, float mapHalf, float* nx, float* ny) {
    if (mapHalf <= 0) mapHalf = 60.0f;
    *nx = wx / mapHalf * 0.5f + 0.5f;
    *ny = wz / mapHalf * 0.5f + 0.5f;
}
