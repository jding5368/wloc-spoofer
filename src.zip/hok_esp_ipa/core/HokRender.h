// HokRender.h —— 全图透视帧渲染（纯 C，输出 BGRA）
#pragma once

#include "HokCore.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int width;
    int height;
} HokCanvas;

// 渲染一帧全图透视：底为半透明地图盘，敌方红点发光、友方蓝、自己绿
// out 至少 w*h*4 字节 BGRA
void hok_render_frame(const HokEnemy* enemies, int count, int w, int h, unsigned char* out);

// 填充纯色（无数据时占位）
void hok_render_solid(int w, int h, unsigned char r, unsigned char g, unsigned char b,
                      unsigned char* out);

#ifdef __cplusplus
}
#endif
