// HokCore.h —— 跨进程内存读取 + il2cpp 运行时定位（TrollStore 版）
#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <mach/mach.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- 基础类型 ----
typedef struct {
    float x, y, z;      // 世界坐标（米）
} HokVec3;

typedef struct {
    float x, y, z;      // 世界坐标（米）
    int camp;           // 0 自己 / 1 敌方 / 2 友方
    int hp;
    int maxHp;
    bool dead;
    bool isHero;
    bool valid;
} HokEnemy;

// ---- 运行时偏移配置（由 Il2CppDumper/Frida 生成，见 tools/dump_runtime.py） ----
typedef struct {
    // libil2cpp 加载信息
    uint64_t il2cppBase;             // 0 = 自动定位
    uint64_t metadataRegistrationOff; // Il2CppMetadataRegistration 相对 libil2cpp 基址
    // Il2CppClass 布局（相对 class 指针）
    uint32_t classFieldsOff;         // Il2CppClass.fields 偏移
    uint32_t classStaticFieldsOff;   // Il2CppClass.static_fields 偏移
    uint32_t classInstanceSizeOff;   // Il2CppClass.instance_size 偏移
    // Il2CppFieldInfo 布局
    uint32_t fieldOffsetOff;         // Il2CppFieldInfo.offset 偏移（v29+ 才有，0 表示用旧布局）
    // ActorRoot / ActorManager 的 metadata 类型定义索引
    int32_t actorRootTypeIndex;
    int32_t actorManagerTypeIndex;
    // ActorManager 静态单例字段在 static_fields 里的偏移（Frida 枚举得到）
    uint64_t actorManagerInstanceFieldOff;
    // ActorManager 实例里 List<ActorRoot> 字段偏移
    uint64_t actorListFieldOff;
    // ActorRoot 字段偏移（Il2CppDumper dump.cs 得到）
    uint64_t offLocation;
    uint64_t offForward;
    uint64_t offHp;
    uint64_t offEp;
    uint64_t offCamp;
    uint64_t offConfigId;
    uint64_t offDead;
    uint64_t offVisible;
    uint64_t offIsHero;
    // 地图
    float mapHalf;                   // 地图半边长（米）
    float vIntScale;                 // VInt3 精度
} HokConfig;

typedef struct {
    task_t task;                     // 已获取的目标进程 task port
    uint64_t il2cppBase;             // 实际 libil2cpp 基址
    uint64_t metadataReg;            // Il2CppMetadataRegistration 地址
    uint64_t typesArray;             // types 数组地址（Il2CppType**）
    uint32_t typesCount;
    uint64_t actorRootClass;         // Il2CppClass*
    uint64_t actorManagerClass;      // Il2CppClass*
} HokRuntime;

// ---- 生命周期 ----
// 通过进程名找 pid 并获取 task port（需 task_for_pid-allow）
bool hok_attach(const char* procName, HokRuntime* rt, char* err, size_t errLen);

// 用配置文件定位 il2cpp 运行时 + 目标类
bool hok_resolve(const HokConfig* cfg, HokRuntime* rt, char* err, size_t errLen);

// 扫描所有敌人
int hok_scan(const HokConfig* cfg, HokRuntime* rt, HokEnemy* out, int maxOut);

// 世界坐标 → 小地图归一化
void hok_world_to_minimap(float wx, float wz, float mapHalf, float* nx, float* ny);

#ifdef __cplusplus
}
#endif
